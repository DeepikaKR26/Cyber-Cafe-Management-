# CCMS
Using HTML,CSS,PHP,and MySQL (Database
Management System Project) -This project aims to develop a computer system for a
cyber cafe to streamline the management of user details, cabin allocation, login
history, internet usage, and billing. The software will include functionalities such as
user registration, login, and password management.

# E-R Diagram
![image](https://github.com/balakrishnasajja/Cyber-cafe-management-system/assets/95561879/80aca021-65ed-4790-9be9-6f053e3f4015)

![image](https://github.com/balakrishnasajja/Cyber-cafe-management-system/assets/95561879/680de758-a51d-4ae5-8e29-a5f550009546)

![image](https://github.com/balakrishnasajja/Cyber-cafe-management-system/assets/95561879/0d8c7cea-b4d5-4e88-9212-5a840fcfccdf)

![image](https://github.com/balakrishnasajja/Cyber-cafe-management-system/assets/95561879/f8ace93d-7541-4ff9-a344-cde614123b7d)
